const initialState = {}

const profiles = (state = initialState, action) => {
  return state
}

export default profiles
